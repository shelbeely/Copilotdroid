Agent HQ Android — Copilot Coding Agent session manager.
Dashboard + PR review + steering + analytics.